package com.example.horsecart;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.vehicle.VehicleDestroyEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

import java.util.*;

/**
 * HorseCart: a storage-minecart based wagon that tamed horses can pull.
 *  - Right-click cart            -> sit (2 seats)
 *  - Sneak + right-click cart    -> open storage (27 slots)
 *  - Right-click cart with Lead  -> hitch / unhitch a tamed horse
 */
public final class HorseCartPlugin extends JavaPlugin implements Listener, CommandExecutor {

    // ---- tuning ----
    private static final double HITCH_DISTANCE = 2.6;  // blocks between horse and cart
    private static final double MAX_PULL_SPEED = 0.55; // blocks per tick
    private static final double MAX_ROPE       = 14.0; // rope snaps beyond this
    private static final int    MAX_SEATS      = 2;
    private static final float  YAW_OFFSET     = 90f;  // minecart model axis
    private static final Material DISPLAY_BLOCK = Material.BARREL;

    private NamespacedKey cartKey, seatKey, itemKey;
    private final Map<UUID, UUID> hitches = new HashMap<>(); // cart -> horse

    @Override
    public void onEnable() {
        saveDefaultConfig();
        cartKey = new NamespacedKey(this, "cart");
        seatKey = new NamespacedKey(this, "seat");
        itemKey = new NamespacedKey(this, "cart_item");

        getServer().getPluginManager().registerEvents(this, this);
        Objects.requireNonNull(getCommand("horsecart")).setExecutor(this);

        ShapedRecipe r = new ShapedRecipe(new NamespacedKey(this, "horse_cart"), cartItem());
        r.shape("PCP", "I I");
        r.setIngredient('P', new RecipeChoice.MaterialChoice(Tag.PLANKS));
        r.setIngredient('C', Material.CHEST);
        r.setIngredient('I', Material.IRON_INGOT);
        Bukkit.addRecipe(r);

        Bukkit.getScheduler().runTaskTimer(this, this::tickHitches, 1L, 1L);
    }

    // ------------------------------------------------------------ items

    private ItemStack cartItem() {
        ItemStack it = new ItemStack(Material.CHEST_MINECART);
        ItemMeta m = it.getItemMeta();
        m.setDisplayName("§6Horse Cart");
        m.setLore(List.of("§7Lead + right-click: hitch a tamed horse",
                          "§7Right-click: sit",
                          "§7Sneak + right-click: storage"));
        m.getPersistentDataContainer().set(itemKey, PersistentDataType.BYTE, (byte) 1);
        it.setItemMeta(m);
        return it;
    }

    private boolean isCartItem(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return false;
        return it.getItemMeta().getPersistentDataContainer().has(itemKey, PersistentDataType.BYTE);
    }

    private boolean isCart(Entity e) {
        return e instanceof StorageMinecart
                && e.getPersistentDataContainer().has(cartKey, PersistentDataType.BYTE);
    }

    private StorageMinecart spawnCart(Location loc, float playerYaw) {
        loc.setYaw(playerYaw + YAW_OFFSET);
        loc.setPitch(0);
        return loc.getWorld().spawn(loc, StorageMinecart.class, c -> {
            c.getPersistentDataContainer().set(cartKey, PersistentDataType.BYTE, (byte) 1);
            c.setDisplayBlockData(Bukkit.createBlockData(DISPLAY_BLOCK));
            c.setMaxSpeed(MAX_PULL_SPEED + 0.3);
            c.setSlowWhenEmpty(false);
        });
    }

    // ------------------------------------------------------------ events

    @EventHandler
    public void onPlace(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND || e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Player p = e.getPlayer();
        ItemStack inHand = p.getInventory().getItemInMainHand();
        if (!isCartItem(inHand) || e.getClickedBlock() == null) return;

        e.setCancelled(true);
        Location loc = e.getClickedBlock().getRelative(e.getBlockFace()).getLocation().add(0.5, 0.05, 0.5);
        spawnCart(loc, p.getLocation().getYaw());
        if (p.getGameMode() != GameMode.CREATIVE) inHand.setAmount(inHand.getAmount() - 1);
    }

    @EventHandler
    public void onInteractCart(PlayerInteractEntityEvent e) {
        Entity clicked = e.getRightClicked();
        if (!isCart(clicked)) return;
        Player p = e.getPlayer();
        boolean lead = p.getInventory().getItemInMainHand().getType() == Material.LEAD;

        if (!lead && p.isSneaking()) return; // let vanilla open the storage GUI
        e.setCancelled(true);
        if (e.getHand() != EquipmentSlot.HAND) return;

        StorageMinecart cart = (StorageMinecart) clicked;
        if (lead) toggleHitch(p, cart); else sit(p, cart);
    }

    @EventHandler
    public void onBreak(VehicleDestroyEvent e) {
        if (!isCart(e.getVehicle())) return;
        e.setCancelled(true);
        boolean creative = e.getAttacker() instanceof Player p && p.getGameMode() == GameMode.CREATIVE;
        breakCart((StorageMinecart) e.getVehicle(), creative);
    }

    // ------------------------------------------------------------ logic

    private void sit(Player p, StorageMinecart cart) {
        if (p.isInsideVehicle()) return;

        ArmorStand free = null;
        int seats = 0;
        for (Entity pass : cart.getPassengers()) {
            if (pass instanceof ArmorStand a
                    && a.getPersistentDataContainer().has(seatKey, PersistentDataType.BYTE)) {
                seats++;
                if (free == null && a.getPassengers().isEmpty()) free = a;
            }
        }
        if (free == null) {
            if (seats >= MAX_SEATS) { p.sendMessage("§cThe cart is full."); return; }
            free = cart.getWorld().spawn(cart.getLocation(), ArmorStand.class, a -> {
                a.setVisible(false);
                a.setGravity(false);
                a.setMarker(true);
                a.setInvulnerable(true);
                a.setSilent(true);
                a.setPersistent(false);
                a.getPersistentDataContainer().set(seatKey, PersistentDataType.BYTE, (byte) 1);
            });
            cart.addPassenger(free);
        }
        free.addPassenger(p);
    }

    private boolean hitchable(AbstractHorse h) {
        return h.isTamed() && h.isAdult() && !hitches.containsValue(h.getUniqueId());
    }

    private void toggleHitch(Player p, StorageMinecart cart) {
        if (hitches.remove(cart.getUniqueId()) != null) {
            p.sendMessage("§eHorse unhitched.");
            return;
        }
        AbstractHorse horse = null;
        if (p.getVehicle() instanceof AbstractHorse h && hitchable(h)) {
            horse = h;
        } else {
            double best = Double.MAX_VALUE;
            for (Entity en : cart.getNearbyEntities(8, 4, 8)) {
                if (en instanceof AbstractHorse h && hitchable(h)) {
                    double d = h.getLocation().distanceSquared(cart.getLocation());
                    if (d < best) { best = d; horse = h; }
                }
            }
        }
        if (horse == null) {
            p.sendMessage("§cNo free tamed adult horse nearby (within 8 blocks).");
            return;
        }
        hitches.put(cart.getUniqueId(), horse.getUniqueId());
        p.sendMessage("§aHorse hitched. Ride it and go!");
    }

    private void breakCart(StorageMinecart cart, boolean creative) {
        hitches.remove(cart.getUniqueId());
        for (Entity pass : new ArrayList<>(cart.getPassengers())) pass.remove(); // seats (ejects riders)
        World w = cart.getWorld();
        Location l = cart.getLocation();
        for (ItemStack it : cart.getInventory().getContents()) {
            if (it != null && it.getType() != Material.AIR) w.dropItemNaturally(l, it);
        }
        cart.getInventory().clear();
        if (!creative) w.dropItemNaturally(l, cartItem());
        cart.remove();
    }

    /** Runs every tick: drags each hitched cart behind its horse like a rope. */
    private void tickHitches() {
        Iterator<Map.Entry<UUID, UUID>> it = hitches.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, UUID> en = it.next();
            Entity ce = Bukkit.getEntity(en.getKey());
            Entity he = Bukkit.getEntity(en.getValue());
            if (!(ce instanceof StorageMinecart cart) || !cart.isValid()
                    || !(he instanceof AbstractHorse horse) || !horse.isValid()
                    || !cart.getWorld().equals(horse.getWorld())) {
                it.remove();
                continue;
            }

            Location cl = cart.getLocation(), hl = horse.getLocation();
            double dx = hl.getX() - cl.getX(), dz = hl.getZ() - cl.getZ();
            double dist = Math.sqrt(dx * dx + dz * dz);

            if (dist > MAX_ROPE || Math.abs(hl.getY() - cl.getY()) > 8) {
                it.remove(); // rope snapped
                for (Entity pass : horse.getPassengers())
                    if (pass instanceof Player pl) pl.sendMessage("§cThe cart came unhitched (too far).");
                continue;
            }

            double nx = dist > 1e-6 ? dx / dist : 0, nz = dist > 1e-6 ? dz / dist : 0;
            double speed = dist > HITCH_DISTANCE ? Math.min(MAX_PULL_SPEED, (dist - HITCH_DISTANCE) * 0.6) : 0;
            double vy = cart.getVelocity().getY();

            // hop up 1-block steps
            if (speed > 0.02 && cart.isOnGround()) {
                Block ahead = cl.clone().add(nx * 0.9, 0.1, nz * 0.9).getBlock();
                if (!ahead.isPassable()
                        && ahead.getRelative(BlockFace.UP).isPassable()
                        && ahead.getRelative(0, 2, 0).isPassable()) {
                    vy = 0.42;
                }
            }

            cart.setVelocity(new Vector(nx * speed, vy, nz * speed));
            if (dist > 0.5) {
                float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz)) + YAW_OFFSET;
                cart.setRotation(yaw, 0f);
            }
        }
    }

    // ------------------------------------------------------------ resource pack

    private String packUrl() {
        return getConfig().getString("resource-pack.url", "").trim();
    }

    /** Sends a clickable download link (if a pack URL is configured). */
    private void sendPackLink(CommandSender to) {
        String url = packUrl();
        if (url.isEmpty()) {
            to.sendMessage("§cNo resource pack has been set for HorseCart.");
            return;
        }
        to.sendMessage(Component.text("HorseCart resource pack: ", NamedTextColor.GOLD)
                .append(Component.text(url, NamedTextColor.AQUA)
                        .clickEvent(ClickEvent.openUrl(url))));
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        String url = packUrl();
        if (url.isEmpty()) return;
        Player p = e.getPlayer();

        if (getConfig().getBoolean("resource-pack.send-link-on-join", true)) {
            sendPackLink(p);
        }
        if (getConfig().getBoolean("resource-pack.auto-apply", false)) {
            String sha1 = getConfig().getString("resource-pack.sha1", "").trim();
            if (sha1.length() == 40) {
                byte[] hash = new byte[20];
                for (int i = 0; i < 20; i++)
                    hash[i] = (byte) Integer.parseInt(sha1.substring(i * 2, i * 2 + 2), 16);
                p.setResourcePack(url, hash);
            } else {
                p.setResourcePack(url);
            }
        }
    }

    // ------------------------------------------------------------ command

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage("§e/horsecart give [player]  |  spawn  |  pack  |  reload");
            return true;
        }
        String sub = args[0].toLowerCase();
        if (!sub.equals("pack") && !sender.hasPermission("horsecart.admin")) {
            sender.sendMessage("§cNo permission.");
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "give" -> {
                Player target = args.length > 1 ? Bukkit.getPlayerExact(args[1])
                        : (sender instanceof Player self ? self : null);
                if (target == null) { sender.sendMessage("§cPlayer not found."); return true; }
                target.getInventory().addItem(cartItem());
                sender.sendMessage("§aHorse Cart given.");
            }
            case "spawn" -> {
                if (!(sender instanceof Player pl)) { sender.sendMessage("§cPlayers only."); return true; }
                Vector fwd = pl.getLocation().getDirection().setY(0).normalize().multiply(2);
                spawnCart(pl.getLocation().add(fwd), pl.getLocation().getYaw());
            }
            case "pack" -> sendPackLink(sender);
            case "reload" -> { reloadConfig(); sender.sendMessage("§aHorseCart config reloaded."); }
            default -> sender.sendMessage("§e/horsecart give [player]  |  spawn  |  pack  |  reload");
        }
        return true;
    }
}
